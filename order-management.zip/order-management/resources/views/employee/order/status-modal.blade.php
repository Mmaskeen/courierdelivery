<div class="modal fade at-viewstatusmodal at-modal" id="at-viewstatusmodal" tabindex="-1" role="dialog" aria-labelledby="at-viewstatusmodal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Order Detail</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="at-viewstatusholder">
                    <div class="at-viewstatushead">
                        <span>Name</span>
                        <span>Status</span>
                        <span>Date/Time</span>
                    </div>
                    <ul class="at-viewstatuscontent">
                        {{--                        <li>--}}
                        {{--                            <h2>Waleed</h2>--}}
                        {{--                        </li>--}}
                        {{--                        <li>--}}
                        {{--                            <em class="at-statuspreview badge-Dispatched">Dispatched</em>--}}
                        {{--                        </li>--}}
                        {{--                        <li>--}}
                        {{--                            <h2>12: 30</h2>--}}
                        {{--                        </li>--}}
                    </ul>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
