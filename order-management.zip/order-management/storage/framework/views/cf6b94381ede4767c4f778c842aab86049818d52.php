<?php $__env->startSection('page-title'); ?>
    <title>Admin | Edit Profile</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container">
            <div class="page-header">
                <h4 class="page-title">Edit Profile</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page">Edit Profile</li>
                </ol>

            </div>
            <div class="row row-deck">
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">My Profile</h3>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('update-profile',[\Illuminate\Support\Facades\Auth::user()->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row mb-2">
                                    <div class="col-auto">
                                        <span class="avatar brround avatar-xl cover-image" data-image-src="<?php echo e(asset('uploads/users-profile/'.\Illuminate\Support\Facades\Auth::user()->avatar)); ?>"></span>
                                    </div>
                                    <div class="col">
                                        <h3 class="mb-1 "><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></h3>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Bio</label>
                                    <textarea name="bio" class="form-control" rows="5"><?php echo e(\Illuminate\Support\Facades\Auth::user()->bio); ?></textarea>
                                    <?php if ($errors->has('bio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bio'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                </div>
                                <div class="form-group">
                                    <label class="form-label">Email-Address</label>
                                    <input class="form-control"  value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->email); ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Old Password</label>
                                    <input type="password" name="old_password" class="form-control" placeholder="Old Password"/>
                                    <?php if ($errors->has('old_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('old_password'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                </div>
                                <div class="form-group">
                                    <label class="form-label">New Password</label>
                                    <input type="password" name="password" class="form-control" placeholder="New Password"/>
                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                </div>
                                <div class="form-group">
                                    <label class="form-label">Confirm Password</label>
                                    <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password"/>
                                    <?php if ($errors->has('password_confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password_confirmation'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                </div>
                                <div class="form-footer">
                                    <button type="submit" class="btn btn-primary btn-block">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/profile/edit-profile.blade.php ENDPATH**/ ?>