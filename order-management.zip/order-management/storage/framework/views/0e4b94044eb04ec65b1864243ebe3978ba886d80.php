<?php $__env->startSection('page-title'); ?>
    <title>Admin | Reports</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container-fluid">
            <div class=" content-area">
                <div class="page-header">
                    <h4 class="page-title">Order Sales Reports</h4>
                    <ol class="breadcrumb">
                        
                        
                    </ol>
                </div>



                <div class="row">
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    




                    
                    
                    
                    

                    <div class="col-lg-6 col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Sales Report</h3>
                            </div>
                            <div class="mt-2 mb-3 text-center">
                                <span class="dot-label bg-primary"></span><span class="mr-3 Revenue1">Karachi</span>
                                <span class="dot-label bg-secondary"></span><span class="mr-3 Revenue1">Other Cities</span>
                            </div>
                            <div class="card-body">
                                <div class="mt-2 mb-3 text-center">
                                    <select id="salesReport">
                                        <option value="Daily" selected>Daily</option>
                                        <option value="Weekly">Weekly</option>
                                        <option value="Monthly">Monthly</option>
                                        <option value="Yearly">Yearly</option>
                                    </select>
                                </div>
                                <div id="salesReportChart" class="chartsh chart-dropshadow"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Staff Today Report</h3>
                            </div>
                            <div class="card-body">
                                <div class="mt-2 mb-3 text-center">

                                    <select id="employee_id">
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div id="staff-activities" class="chartsh chart-dropshadow"></div>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('assets/js/morris.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            let salesReport = $('#salesReport').val();
            $("#salesReport").on('change',function () {
                $("#salesReportChart").empty();
                let salesReport = $("#salesReport :selected").val();
                let url = '<?php echo e(route('admin_sales_report','data')); ?>';
                url = url.replace('data',salesReport);
                $.ajax({
                    url: url,
                    method:"GET",
                    success:function (response) {
                        console.log(response);
                        $("#salesReportChart").empty();

                        new Morris.Bar({
                            element: 'salesReportChart',
                            data: response,
                            xkey: 'period',
                            ykeys: ['karachi', 'Other City'],
                            labels: ['karachi', 'Other City'],
                            barColors: ['#ff685c', '#32cafe'],
                            xLabelAngle: 0,
                        });
                    }

                })
            });
            $.ajax({
                url:'/admin/sales/report/'+salesReport,
                method:"GET",
                success:function (response) {
                    console.log(response);
                    new Morris.Bar({
                        element: 'salesReportChart',
                        data: response,
                        xkey: 'period',
                        ykeys: ['karachi', 'Other City'],
                        labels: ['karachi', 'Other City'],
                        barColors: ['#ff685c', '#32cafe'],
                        xLabelAngle: 0,
                    });
                }

            });

            var employeeId = $("#employee_id").val();
            $("#employee_id").on('change',function () {
                var employeeId = $("#employee_id :selected").val();
                $.ajax({
                    url:'/admin/staff/activities/'+employeeId,
                    method:"GET",
                    success:function (response) {
                        $("#staff-activities").empty();
                        new Morris.Bar({
                            hideHover: 'auto',
                            element: 'staff-activities',
                            data:response,
                            xkey: 'y',
                            ykeys: ['a'],
                            labels: ['Total Income'],
                            Colors: ['#ff685c ', '#32cafe'],
                            xLabelAngle: 0
                        });
                    }

                })
            });
            $.ajax({
                url:'/admin/staff/activities/'+employeeId,
                method:"GET",
                success:function (response) {
                    new Morris.Bar({
                        element: 'staff-activities',
                        data:response,
                        xkey: 'y',
                        ykeys: ['a'],
                        labels: ['Total Income'],
                        Colors: ['#ff685c ', '#32cafe'],
                        xLabelAngle: 0
                    });
                }

            })


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/admin/report/report.blade.php ENDPATH**/ ?>