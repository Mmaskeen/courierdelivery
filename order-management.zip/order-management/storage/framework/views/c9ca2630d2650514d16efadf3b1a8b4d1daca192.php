<?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('style'); ?>
<body class="app sidebar-mini rtl">
<div id="global-loader" ></div>
<div class="page">
    <div class="page-main">
        <div class="app-header header py-1 d-flex">
            <div class="container">
                <div class="d-flex">
                    <!-- <a class="header-brand" href="index.html">
                        <img src="assets/images/brand/logo.png" class="header-brand-img d-none d-sm-block" alt="Spain logo">
                        <img src="assets/images/brand/logo.png" class="header-brand-img-2 d-sm-none" alt="Spain logo">
                    </a> -->
                    <a id="horizontal-navtoggle" class="animated-arrow"><span></span></a>


                    <div class="d-flex order-lg-2 ml-auto ">
                        
                        
                        
                        
                        
                        
                        <div class="dropdown d-none d-md-flex " >
                            <a  class="nav-link icon full-screen-link">
                                <i class="mdi mdi-arrow-expand-all"  id="fullscreen-button"></i>
                            </a>
                        </div>
                        <div class="dropdown d-none d-md-flex" id="notification-dropdown">
                            <a class="nav-link icon" data-toggle="dropdown" >
                                <i class="mdi mdi-bell-outline "></i>
                                <span class="nav-unread bg-success <?php echo e(auth()->user()->unreadNotifications->count() ? '' : 'hide'); ?>"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow notificationsList notification">
                                <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(auth()->user()->getNewOrderUrl().'/'.$notification->data['order_id']); ?>" class="dropdown-item d-flex pb-3 bg-lime-light">
                                        <div class="notifyimg">
                                            <i class="fa fa-thumbs-o-up"></i>
                                        </div>
                                        <div>
                                            <strong>You have a new order.</strong>
                                            <div class="small text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = auth()->user()->readNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(auth()->user()->getNewOrderUrl().'/'.$notification->data['order_id']); ?>" class="dropdown-item d-flex pb-3 ">
                                        <div class="notifyimg">
                                            <i class="fa fa-thumbs-o-up"></i>
                                        </div>
                                        <div>
                                            <strong>You have a new order.</strong>
                                            <div class="small text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></div>
                                        </div>
                                    </a>
                                    <?php if($key == 8): ?>
                                        <?php break; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="dropdown-divider"></div>
                                <a href="index4.html#" class="dropdown-item text-center">View all Notification</a>
                            </div>
                        </div>

                        <div class="dropdown">
                            <a href="index4.html#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                                <span class="avatar avatar-md brround"><img src="<?php echo e(asset('uploads/users-profile/'.\Illuminate\Support\Facades\Auth::user()->avatar)); ?>" alt="Profile-img" class="avatar avatar-md brround"></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow ">
                                <div class="text-center">
                                    <a href="#" class="dropdown-item text-center font-weight-sembold user"><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></a>

                                    <div class="dropdown-divider"></div>
                                </div>
                                <a class="dropdown-item" href="<?php echo e(route('edit-profile')); ?>">
                                    <i class="dropdown-icon mdi mdi-account-outline "></i> Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                                    <i class="dropdown-icon mdi  mdi-logout-variant"></i> Sign out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Horizontal-menu-->
<?php if(auth()->user()->isAdmin()): ?>
    <?php echo $__env->make('layouts.header-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('employee.header-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /var/www/order-management/resources/views/layouts/header.blade.php ENDPATH**/ ?>