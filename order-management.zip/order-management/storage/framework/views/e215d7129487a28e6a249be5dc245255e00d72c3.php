
<?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td>
            <?php if($order->status === 'Dispatched' && $order->dispatch_status === 'Parcel Returned' || $order->status === 'Dispatched' && $order->dispatch_status === 'RETURN TO SHIPPER'): ?>
                <label class="custom-switch mr-3">
                    <input type="checkbox" name="is_returned" data-id="<?php echo e($order->id); ?>" class="custom-switch-input isReturned" <?php echo e($order->is_returned == 1 ? 'checked' : ''); ?>>
                    <span class="custom-switch-indicator"></span>
                </label>
            <?php endif; ?>
            <span class="text-muted orderId"><?php echo e($order->order_id); ?></span>
        </td>
        <?php if(request('statusFilter') === 'Dispatched'): ?>
            <td><span class="text-muted orderId"><?php echo e($order->cn ? $order->cn : 'N/A'); ?>

                    <?php if($order->dispatch_by == 'Tcs' || $order->dispatch_by == 'Stallion'): ?>
                        <figure class="at-logimg"><img <?php echo e($order->dispatch_by == 'Tcs' || $order->dispatch_by == 'Stallion' ?
                     'src='.asset('assets/images/'.$order->dispatch_by.'.png'): ''); ?>  alt="logo image"></figure>
                    <?php else: ?>
                        <strong style="color: black"> (<?php echo e($order->dispatch_by !== null && $order->rider ?  $order->rider->name  : ''); ?>) </strong>

                    <?php endif; ?>
                </span>
            </td>
            <td><span class="text-muted orderId"><?php echo e($order->dispatch_status ? $order->dispatch_status : 'N/A'); ?></span></td>
        <?php endif; ?>
        <td><a href="<?php echo e(route('employee_edit_order',['id' => $order->id, 'url' => request()->fullUrl()])); ?>"><?php echo e(str_limit($order->name,10)); ?></a></td>
        <td title="<?php echo e($order->product); ?>"><a href="<?php echo e($order->product); ?>" target="_blank"><?php echo e(str_limit($order->product,15)); ?></a></td>
        <td><?php echo e(str_limit($order->address,15)); ?></td>
        <td><?php echo e(str_limit($order->city,15)); ?></td>
        <td>
            <?php $__currentLoopData = $order->orderNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e(str_limit($num->mobile,6)); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td><?php echo e($order->quantity); ?></td>
        <td><?php echo e($order->price); ?></td>
        <td><span class="badge badge-<?php echo e($order->status); ?> mt-2"><?php echo e($order->status); ?></span></td>
        <td><?php echo e($order->created_at_m_d_y); ?></td>
        <td>
            <div class="btn-group mt-2 mb-2">
                <?php if(request('statusFilter') === 'Dispatched'): ?>
                    <form action="<?php echo e(route('employee_change_dispatch_order_status',$order->id)); ?>" method="post" class="btnform">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="status" value="Canceled">
                        <button type="submit" class="at-actionbtn btn-primary">Cancel <span class="caret"></span></button>
                    </form>
                    <form action="<?php echo e(route('employee_change_dispatch_order_status',$order->id)); ?>" method="post" class="btnform">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="status" value="Hold Order">
                        <button type="submit" class="at-actionbtn btn-primary">Hold <span class="caret"></span></button>
                    </form>
                <?php endif; ?>
                <?php if($order->status !== 'Dispatched'): ?>
                    <a href="<?php echo e(route('employee_edit_order',['id' => $order->id, 'url' => request()->fullUrl()])); ?>" class="at-actionbtn at-edit-icon" ><i class="fa fa-edit"></i></a>
                <?php endif; ?>










            </div>


        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>

<?php /**PATH /var/www/order-management/resources/views/employee/order/order-table.blade.php ENDPATH**/ ?>