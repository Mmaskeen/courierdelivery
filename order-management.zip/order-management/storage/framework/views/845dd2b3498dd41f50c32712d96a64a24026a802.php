<?php $__env->startSection('page-title'); ?>
    <title>Employee | Edit Order</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container-fluid">
            <div class="page-header">
                <h4 class="page-title">Order</h4>
            </div>
            <div class="row">
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 card-title">Edit Order</h3>
                        </div>
                        <form method="post" action="<?php echo e(route('employee_update_order',$order->id)); ?>" enctype="multipart/form-data" onsubmit="myButton.disabled = true; return true;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="redirectUrl" value="<?php echo e($url); ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Shop Name</label>
                                            <input type="text" class="form-control" value="<?php echo e($order->shop_name); ?>" name="shop_name" placeholder="Shop Name">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Enter Name</label>
                                            <input type="text" class="form-control" value="<?php echo e($order->name); ?>" name="customer_name" placeholder="Name">
                                            <?php if ($errors->has('customer_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_name'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Product</label>
                                            <input type="text" class="form-control" value="<?php echo e($order->product); ?>" onclick="window.open( '<?php echo e($order->product); ?>')" name="product_url" placeholder="Product">
                                            <?php if ($errors->has('product_url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_url'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Email</label>
                                            <input type="text" class="form-control" value="<?php echo e($order->email); ?>" name="customer_email" placeholder="Email..">
                                            <?php if ($errors->has('customer_email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_email'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group m-0">
                                            <label class="form-label">Mobile</label>
                                            <?php $__currentLoopData = $order->orderNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input type="text"  class="form-control mobile" value="<?php echo e($number->mobile); ?>" name="mobile[]" placeholder="Mobile Number" required>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <?php if($order->status == 'Dispatched'): ?>

                                        <div class="form-group m-0">
                                            <label class="form-label">CN</label>
                                                <input type="text"  class="form-control " value="<?php echo e($order->cn); ?>" disabled >
                                        </div>

                                         <div class="form-group m-0">
                                            <label class="form-label">Dispatch Status</label>
                                                <input type="text"  class="form-control" value="<?php echo e($order->dispatch_status); ?>" name="<?php echo e($order->dispatch_by == "Tcs" || $order->dispatch_by == "Stallion" ? '' : 'dispatch_status'); ?>" <?php echo e($order->dispatch_by == "Tcs" || $order->dispatch_by == "Stallion" ? 'disabled' : ''); ?>>
                                        </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <label class="form-label">City</label>
                                            <select class="form-control cities" name="city" data-placeholder="Choose City">
                                                <option value="" disabled selected>Select The City</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($city->name); ?>"  <?php echo e($order->city == $city->name ? "selected" : ""); ?>><?php echo e($city->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group" id="dispatchBy" style="display: <?php echo e($order->dispatch_by == null ? 'none' : 'blocked'); ?>" >
                                            <label class="form-label">Dispatch By</label>
                                            <select class="form-control" id="dispatchSelect" name="dispatch_by" data-placeholder="Choose Service">
                                                <option value="">Select The Service</option>
                                                <option value="Tcs"<?php echo e($order->dispatch_by == 'Tcs' ? 'selected' : ''); ?>>Tcs</option>
                                                <option value="Stallion"<?php echo e($order->dispatch_by == 'Stallion' ? 'selected' : ''); ?>>Stallion</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($rider->id); ?>"<?php echo e($order->dispatch_by == $rider->id ? 'selected' : ''); ?>><?php echo e($rider->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php if ($errors->has('dispatch_by')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dispatch_by'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group" id="dispatchCity" style="display: none">
                                            <label class="form-label">Dispatch To</label>
                                            <select class="form-control" id="dispatchTo" name="dispatch_to" data-placeholder="Choose Service">
                                                <option value="" >Select The City</option>
                                            </select>
                                            <?php if ($errors->has('dispatch_to')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dispatch_to'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group" id="dispatchRemark" style="display: none">
                                            <label class="form-label">Dispatch Remark</label>
                                            <input type="text" name="dispatch_remark"  class="form-control" value="<?php echo e($order->dispatch_remark); ?>">

                                            <?php if ($errors->has('dispatch_remark')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dispatch_remark'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Order Id</label>
                                            <input type="text" class="form-control" value="<?php echo e($order->order_id); ?>" name="order_number" placeholder="Order Id">
                                            <?php if ($errors->has('order_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('order_number'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Address</label>
                                            <input type="text" class="form-control" value="<?php echo e($order->address); ?>" name="customer_address" placeholder="Address">
                                            <?php if ($errors->has('customer_address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_address'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group m-0">
                                            <label class="form-label">Quantity</label>
                                            <input type="number" class="form-control" value="<?php echo e($order->quantity); ?>" name="product_quantity" placeholder="Quantity">
                                            <?php if ($errors->has('product_quantity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_quantity'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Price</label>
                                            <input type="number" class="form-control" value="<?php echo e($order->price); ?>" name="price" placeholder="Price">
                                            <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Currency</label>
                                            <input type="text" class="form-control" value="<?php echo e($order->currency); ?>" name="currency" placeholder="Currency">
                                            <?php if ($errors->has('currency')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currency'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Status</label>
                                            <select class="form-control cities" name="status" data-placeholder="Choose Status" <?php echo e($order->status == 'Dispatched' ? "disabled" : ""); ?>>
                                                <option value="Proceeded" <?php echo e($order->status == 'Proceeded' ? "selected" : ""); ?>>Proceeded</option>
                                                <option value="Latest" <?php echo e($order->status == 'Latest' ? "selected" : ""); ?>>Latest</option>
                                                <option value="Canceled" <?php echo e($order->status == 'Canceled' ? "selected" : ""); ?>>Canceled</option>
                                                <option value="Hold Order" <?php echo e($order->status == 'Hold Order' ? "selected" : ""); ?>>Hold Order</option>
                                                <option value="Dispatched" <?php echo e($order->status == 'Dispatched' ? "selected" : ""); ?>>Dispatched</option>
                                            </select>
                                            <?php if ($errors->has('status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('status'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group" id="remark-div">
                                            <label class="form-label">Remarks</label>
                                            <?php if($order->remarks): ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $order->remarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <input type="text" class="form-control" name="remarks[]" value="<?php echo e($remark->remark); ?>" placeholder="Remarks" <?php echo e($remark->user_id == \Illuminate\Support\Facades\Auth::user()->id ? ' ' : 'disabled'); ?>>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <button class="at-plusicon" id="addRemark"><i class="fa fa-plus" aria-hidden="true"></i></button>
                                        </div>
                                        <div class="form-group" id="invoice-div" style="display: none">
                                            <label class="form-label">Invoice Record</label>

                                            <?php if($order->invoices): ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $order->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <input type="text" class="form-control" name="invoices[]" value="<?php echo e($invoice->name); ?>-<?php echo e($invoice->quantity); ?>-<?php echo e($invoice->price); ?>" placeholder="Name-quantity-price">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <input type="text" class="form-control" name="invoices[]" value="" placeholder="Name-quantity-price">
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if ($errors->has('invoices')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('invoices'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            <button class="at-plusicon" id="addInvoice"><i class="fa fa-plus" aria-hidden="true"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if($order->status == 'Dispatched'): ?>
                                <button class="btn btn-primary" href="##" onClick="history.go(-1); return false;">Go back</button>
                            <?php else: ?>
                                <button type="submit" name="myButton" class="btn btn-primary">Update Order</button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            let dispatchByStatus = '';

            // $('.mobile').mask('0000-000000000000000000000000000000');
            $(document).on('click','#addRemark',function (e) {
                e.preventDefault();
                let input = '<input type="text" class="form-control" name="remarks[]" value="" placeholder="Remarks">';
                $('#remark-div').append(input);
            });

            $(document).on('click','#addInvoice',function (e) {
                e.preventDefault();
                let input = '<input type="text" class="form-control" name="invoices[]" value="" placeholder="Name-quantity-price">';
                $('#invoice-div').append(input);
            });

            $('select[name="status"]').on('change',function (e) {
                let status = $(this).val();
                console.log(status);
                if(status === 'Dispatched'){
                    $('#dispatchBy').css('display','block');
                    $('#invoice-div').css('display','block');
                    $('#dispatchSelect').attr('required', true);
                }else{
                    $('#dispatchBy').css('display','none');
                    $('#dispatchSelect').val("null");
                    $('#invoice-div').css('display','none');
                    $('#dispatchSelect').removeAttr('required');
                }
            });

            $('select[name="dispatch_to"]').on('change',function (e) {
                let dispatch_to = $(this).val();
                console.log(dispatch_to,dispatch_to === '');
                if(dispatch_to !== ''){
                    $('#dispatchRemark').css('display','block');
                    if (dispatchByStatus === 'Stallion'){
                        $('input[name="dispatch_remark"]').attr('required', true);
                    }
                }else{
                    $('#dispatchRemark').css('display','none');
                    $('input[name="dispatch_remark"]').val("");
                    $('input[name="dispatch_remark"]').removeAttr('required', true);
                }
            });

            $('select[name="dispatch_by"]').on('change',function (e) {
                let val = $(this).val();
                dispatchByStatus = val;
                console.log(val,val !== '');
                if(val !== ''){
                    $('#dispatchCity').css('display','block');
                    $('#dispatchTo').attr('required', true);
                    let url = '<?php echo e(route('employee_get_dispatch_city')); ?>';
                    let data = {
                        'type' : val,
                    };
                    $.get(url,data,function (response) {
                        if(response.status == 'success'){
                            console.log(response);
                            $('#dispatchTo').empty();
                            var option = $('<option></option>').attr("value", "").text("Select dispatch City");
                            $('#dispatchTo').append(option);
                            $.each(response.cities,function (key, res) {
                                var option = $('<option></option>').attr("value", res.name).text(res.name);
                                // option.attr('data-id',res.id);
                                $('#dispatchTo').append(option);
                            });
                        }
                    });
                }else{
                    $('#dispatchCity').css('display','none');
                    $('#dispatchTo').val("null");
                    $('#dispatchTo').removeAttr('required');
                }
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/employee/order/edit-order.blade.php ENDPATH**/ ?>