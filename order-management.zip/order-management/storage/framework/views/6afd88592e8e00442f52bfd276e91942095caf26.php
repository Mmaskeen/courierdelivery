<?php $__env->startSection('page-title'); ?>
    <title>Admin | All Users</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container-fluid">
            <div class="page-header">
                <h4 class="page-title">Users</h4>
                
            </div>
            <div class="row row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="table-responsive" >
                            <table class="table card-table table-vcenter text-nowrap" id="table_id">
                                <thead>
                                <tr>
                                    <th>Name </th>
                                    <th>Email</th>
                                    <th>Type </th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody id="mainTableBody">
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><span class="text-muted orderId"><?php echo e($user->name); ?></span></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->role_id == 1 ? 'Admin' : 'Employee'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin_edit_user',$user->id)); ?>" class="at-actionbtn at-edit-icon btn" ><i class="fa fa-edit"></i></a>
                                            <form id="deleteForm<?php echo e($user->id); ?>"  action="<?php echo e(route('admin_delete_user',[$user->id])); ?>" method="post" class="btnform">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="at-actionbtn at-deleticon d-none d-sm-block delete-user" data-id="<?php echo e($user->id); ?>"><i class="ti-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $(document).on('click','.delete-user',function (e) {
                e.preventDefault();
                let id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then(function (result) {
                    if (result.value) {
                        $('#deleteForm'+id).submit();
                    }
                })
            }) ;
        });
    </script>
<?php $__env->stopSection(); ?>








































































<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/admin/user/all-users.blade.php ENDPATH**/ ?>