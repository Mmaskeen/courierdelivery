<?php $__env->startSection('page-title'); ?>
    <title>Employee | All Cities</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container">
            <div class="page-header">
                <h4 class="page-title">Cities</h4>
                <div class="input-group w-30">
                    <form action="<?php echo e(route('employee_all_city')); ?>" method="get" >
                        <input type="text" class="form-control " value="<?php echo e(request('searchCity')); ?>" name="searchCity"  id="searchCity" placeholder="Search for...">
                        <div class="input-group-append ">
                            <button type="submit" class="btn btn-primary br-tr-7 br-br-7" >
                                <i class="fa fa-search " aria-hidden="true"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-12 col-xl-4 col-sm-12">
                        <div class="card  mb-5">
                            <a href="client-detail.php">
                                <div class="card-body">
                                    <div class="media mt-0">
                                        <div class="media-body">
                                            <h5 class="time-title p-0 mb-0 font-weight-semibold leading-normal"><?php echo e($city->name); ?></h5>
                                        </div>
                                        <form action="<?php echo e(route('employee_edit_city',$city->id)); ?>" method="get" >
                                            <button type="submit" class="btn btn-info d-none d-sm-block mr-2"><i class="fe fe-edit-3"></i> </button>
                                        </form>





                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-lg-12 col-xl-4 col-sm-12">
                        <h3>No data found</h3>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $(document).on('click','.delete-city',function (e) {
                e.preventDefault();
                let id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then(function (result) {
                    if (result.value) {
                        $('#deleteForm'+id).submit();
                    }
                })
            }) ;


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/employee/city/all-city.blade.php ENDPATH**/ ?>