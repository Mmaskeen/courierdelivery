<?php $__env->startSection('page-title'); ?>
    <title>Admin | Trashed Orders</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container-fluid">
            <div class="page-header">
                <h4 class="page-title">Trashed orders</h4>

            </div>

            <div class="row row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <form class="float-left">
                                <button class="btn btn-primary" id="deleteAllPermanent"><i class="fa fa-trash mr-2"></i>Delete All</button>
                                <button  class="btn btn-primary" id="restoreOrders"><i class="fa fa-recycle mr-2"></i>Restore All</button>
                            </form>

                        </div>
                        <div class="table-responsive" >
                            <table class="table card-table table-vcenter text-nowrap" id="table_id">
                                <thead>
                                <tr>
                                    <th>
                                        <span class="at-checkbox">
                                            <input class="checkall" type="checkbox" name="selectall" id="checkall2">
                                            <span id="totalSelected"> (0)</span>
                                            <label for="checkall2"></label>
                                        </span>
                                    </th>
                                    <th class="w-1">Order ID</th>
                                    <th>Name</th>
                                    <th>Product URL</th>
                                    <th>Address</th>
                                    <th>Cell Number</th>
                                    <th>QTY</th>
                                    <th>Price</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody id="mainTableBody">

                                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td data-title="">
                                            <span class="at-checkbox">
                                                <input class="checkboxes" type="checkbox" name="orderCheck" data-id="<?php echo e($order->id); ?>" id="at-user-<?php echo e($order->id); ?>">
                                                <label for="at-user-<?php echo e($order->id); ?>"></label>
                                            </span>
                                        </td>
                                        <td><span class="text-muted orderId"><?php echo e($order->order_id); ?></span></td>
                                        <td><?php echo e(str_limit($order->name,10)); ?></td>
                                        <td title="<?php echo e($order->product); ?>"><a href="<?php echo e($order->product); ?>"><?php echo e(str_limit($order->product,15)); ?></a></td>
                                        <td><?php echo e(str_limit($order->address,15)); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $order->orderNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e(str_limit($num->mobile,6)); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($order->quantity); ?></td>
                                        <td><?php echo e($order->price); ?></td>
                                        <td><span class="badge badge-<?php echo e($order->status); ?> mt-2"><?php echo e($order->status); ?></span></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($order->created_at)->format('M, d, Y')); ?></td>
                                        <td>
                                            <div class="btn-group mt-2 mb-2">
                                                <form action="<?php echo e(route('admin_delete_order',$order->id)); ?>" method="post" class="btnform">
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <input type="hidden" name="type" value="trashed">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="at-actionbtn at-deleticon" title="" onclick="return confirm('Are you sure you want to permanently delete this order?');"><i class="ti-trash"></i></button>
                                                </form>
                                                <form action="<?php echo e(route('admin_restore_order',['order' => $order->id])); ?>" method="post" class="btnform">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="at-actionbtn at-deleticon" title="" onclick="return confirm('Are you sure you want to restore this order?');"><i class="fa fa-recycle"></i></button>
                                                </form>
                                            </div>


                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>


                                </tbody>
                            </table>

                            <?php echo e($orders->links()); ?>




                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $(document).on('click','#deleteAllPermanent',function (e) {
                e.preventDefault();
                let orders =[];
                $("input:checkbox[name=orderCheck]:checked").each(function(){
                    orders.push($(this).data('id'));
                });
                if(orders.length === 0){
                    toastr.error('Please Select at least one order', 'error!')
                }else{
                    let data = { "orders": orders,"_token": "<?php echo e(csrf_token()); ?>","_method" : "DELETE","type" : "permanent"};
                    let url = "<?php echo e(route('admin_delete_multiple_order')); ?>";

                    $.post(url,data,function (response) {
                        if(response.status == 'success'){
                            setTimeout(function(){// wait for 5 secs(2)
                                location.reload(); // then reload the page.(3)
                            }, 10);
                            toastr.success('Orders Deleted Successfully', 'Success!')
                        }else{
                            toastr.error('Something went wrong', 'error!')
                        }
                    });
                }
            });
            $(document).on('click','#restoreOrders',function (e) {
                e.preventDefault();
                let orders =[];
                $("input:checkbox[name=orderCheck]:checked").each(function(){
                    orders.push($(this).data('id'));
                });
                if(orders.length === 0){
                    toastr.error('Please Select at least one order', 'error!')
                }else{
                    let data = { "orders": orders,"_token": "<?php echo e(csrf_token()); ?>",'type':'multiple'};
                    let url = "<?php echo e(route('admin_restore_order')); ?>";

                    $.post(url,data,function (response) {
                        if(response.status == 'success'){
                            setTimeout(function(){// wait for 5 secs(2)
                                location.reload(); // then reload the page.(3)
                            }, 1000);
                            toastr.success('Orders Restore Successfully', 'Success!')
                        }else{
                            toastr.error('Something went wrong', 'error!')
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/admin/order/trashed-order.blade.php ENDPATH**/ ?>