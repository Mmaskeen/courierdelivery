<?php $__env->startSection('page-title'); ?>
    <title>Admin | Add New City</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container">
            <div class="page-header">
                <h4 class="page-title">City</h4>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 card-title">Add New City</h3>
                        </div>
                        <form method="post" action="<?php echo e(route('admin_store_city')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Enter city Name</label>
                                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>"  placeholder="Name" required>
                                        </div>

                                    </div>
                                    <div class="card-footer text-right at-addnewcityfooter">
                                        <button type="submit" class="btn btn-primary">Add City</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/admin/city/create-city.blade.php ENDPATH**/ ?>