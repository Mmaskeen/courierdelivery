<?php $__env->startSection('page-title'); ?>
    <title>Employee | All Orders</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container-fluid">
            <div class="page-header">
                <h4 class="page-title">Orders</h4>
                
            </div>
            <div class="row row-cards">
                <?php if( request('type') == 'overAll' && request('statusFilter') == 'Latest' ||request('type') == 'today'): ?>
                    <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                        <div class="card card-counter bg-gradient-pink">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mt-4 mb-0 text-white">
                                            <h3 class="mb-0"><?php echo e(request('statusFilter') == 'Latest' ? $overAllLP['latestOrders'] : $todayOrder['latestOrders']); ?></h3>
                                            <p class="text-white mt-1">Latest</p>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-truck mt-3 mb-0"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                        <div class="card card-counter bg-gradient-teal">
                            <a href="<?php echo e(route('employee_dispatch_orders')); ?>">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-8">
                                            <div class="mt-4 mb-0 text-white">
                                                <h3 class="mb-0"><?php echo e($todayOrder['totalDispatched']); ?></h3>
                                                <p class="text-white mt-1">Dispatched </p>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <i class="fa fa-truck mt-3 mb-0"></i>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                        <div class="card card-counter bg-gradient-blue">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mt-4 mb-0 text-white">
                                            <h3 class="mb-0"><?php echo e(request('statusFilter') == 'Latest' ? $overAllOrder['totalProcessed'] : $todayOrder['totalProcessed']); ?></h3>
                                            <p class="text-white mt-1">Processed</p>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-truck mt-3 mb-0"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                        <div class="card card-counter bg-gradient-purple">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mt-4 mb-0 text-white">
                                            <h3 class="mb-0"><?php echo e($todayOrder['totalHolderOrders']); ?></h3>
                                            <p class="text-white mt-1">Hold Orders </p>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-truck mt-3 mb-0"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if(request('statusFilter') == 'Latest' && request('type') == 'overAll'): ?>
                        <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                            <div class="card card-counter bg-gradient-purple">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-8">
                                            <div class="mt-4 mb-0 text-white">
                                                <h3 class="mb-0"><?php echo e($todayOrder['totalCanceled']); ?></h3>
                                                <p class="text-white mt-1">canceled Orders </p>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <i class="fa fa-truck mt-3 mb-0"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php elseif(request('type') == 'overAll' && request('statusFilter') == 'Hold Order' || request('type') == 'overAll' && request('statusFilter') == 'Dispatched'  || request('type') == 'overAll'&& request('statusFilter') == 'Proceeded' || request('type') == 'overAll' && request('statusFilter') == 'Canceled' ): ?>
                    <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                        <div class="card card-counter bg-gradient-blue">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mt-4 mb-0 text-white">
                                            <h3 class="mb-0">
                                                <?php switch(request('statusFilter')):
                                                    case ('Hold Order'): ?>
                                                    <?php echo e($overAllStatusBased['karachiHolder']); ?>

                                                    <?php break; ?>
                                                    <?php case ('Proceeded'): ?>
                                                    <?php echo e($overAllStatusBased['karachiProceeded']); ?>

                                                    <?php break; ?>
                                                    <?php case ('Dispatched'): ?>
                                                    <?php echo e($overAllStatusBased['karachiDispatched']); ?>

                                                    <?php break; ?>
                                                    <?php default: ?>
                                                    <?php echo e($overAllStatusBased['karachiCancelled']); ?>

                                                <?php endswitch; ?>
                                            </h3>
                                            <p class="text-white mt-1">Karachi</p>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-truck mt-3 mb-0"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                        <div class="card card-counter bg-gradient-purple">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mt-4 mb-0 text-white">
                                            <h3 class="mb-0">
                                                <?php switch(request('statusFilter')):
                                                    case ('Hold Order'): ?>
                                                    <?php echo e($overAllStatusBased['otherCityHolder']); ?>

                                                    <?php break; ?>
                                                    <?php case ('Proceeded'): ?>
                                                    <?php echo e($overAllStatusBased['otherCityProceeded']); ?>

                                                    <?php break; ?>
                                                    <?php case ('Dispatched'): ?>
                                                    <?php echo e($overAllStatusBased['otherCityDispatched']); ?>

                                                    <?php break; ?>
                                                    <?php default: ?>
                                                    <?php echo e($overAllStatusBased['otherCityCancelled']); ?>

                                                <?php endswitch; ?>
                                            </h3>
                                            <p class="text-white mt-1">Other City </p>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-truck mt-3 mb-0"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                        <div class="card card-counter bg-gradient-secondary shadow-secondary">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mt-4 mb-0 text-white">
                                            <?php if(request('fromDate') != 'null' && request('toDate') != 'null' || request('cityFilter') != 'null' ||
                                             request('statusFilter') != 'null' || request('page')): ?>
                                                <h3 class="mb-0"><?php echo e($filterTotalCanceled); ?></h3>
                                            <?php else: ?>
                                                <h3 class="mb-0"><?php echo e($totalCanceled); ?></h3>
                                            <?php endif; ?>
                                            <p class="text-white mt-1">Canceled Orders </p>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-truck mt-3 mb-0"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    <div class="col-xl-3 col-lg-6 col-md-12 col-sm-12">
                        <div class="card card-counter bg-gradient-purple shadow-secondary">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-8">
                                        <div class="mt-4 mb-0 text-white">
                                            <?php if(request('fromDate') != 'null' && request('toDate') != 'null' || request('cityFilter') != 'null' || request('statusFilter') != 'null'  || request('page')): ?>
                                                <h3 class="mb-0"><?php echo e($filterTotalHold); ?></h3>
                                            <?php else: ?>
                                                <h3 class="mb-0"><?php echo e($totalHold); ?></h3>
                                            <?php endif; ?>
                                            <p class="text-white mt-1">Hold Orders </p>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-truck mt-3 mb-0"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="row row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-inline-block">
                            <div class="row">
                                <div class="col-sm-12">
                                    <h3 class="card-title float-left">Latest Orders</h3>

                                </div>
                                <div class="w-100 mt-2"></div>
                                <div class="col-sm-12">
                                    <ul class="order_filters static">
                                        <form id="orderFilterForm" class="filterform" action="<?php echo e(route('employee_filter_order')); ?>" method="get">
                                            <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
                                            <li>
                                                <div class="input-group float-right">
                                                    <input type="text" class="form-control " value="<?php echo e(request('searchOrder')); ?>" name="searchOrder"  id="search" placeholder="Search for...">
                                                    <div class="input-group-append ">
                                                        <button type="button" class="btn btn-primary br-tr-7 br-br-7" >
                                                            <i class="fa fa-search " aria-hidden="true"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="ml-0">
                                                <div class="at-dateholder">
                                                    <div class="at-startdate">
                                                        <span>From</span>
                                                        <div class="input-group date" data-provide="datepicker">
                                                            <input type="text" name="fromDate" value="<?php echo e(request()->has('fromDate') ? request('fromDate') : ''); ?>" autocomplete="off" class="form-control orderDateFilter">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-calendar at-calendericon" aria-hidden="true"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="at-enddate">
                                                        <span>To</span>
                                                        <div class="input-group date" data-provide="datepicker">
                                                            <input type="text" name="toDate" value="<?php echo e(request()->has('toDate') ? request('toDate') : ''); ?>" autocomplete="off" class="form-control orderDateFilter">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-calendar at-calendericon" aria-hidden="true"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <select name="shopName" class="form-control order-filter" id="shopName">
                                                    <option value="" disabled selected>Select Shop</option>
                                                    <option value="all"<?php echo e(request('shopName') == 'all' ? "selected" : ""); ?>>All</option>
                                                    <?php if($shopNames): ?>
                                                        <?php $__currentLoopData = $shopNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($shopName->shop_name !== null): ?>
                                                                <option  value="<?php echo e($shopName->shop_name); ?>" <?php echo e(request('shopName') == $shopName->shop_name ? "selected" : ""); ?>><?php echo e($shopName->shop_name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </li>
                                            <li>
                                                <select class="form-control cities order-filter" name="cityFilter" data-placeholder="Choose City">
                                                    <option value="" disabled selected>Select The City</option>
                                                    <option value="all"  <?php echo e(request('cityFilter') == 'all' ? "selected" : ""); ?>>All City</option>
                                                    <?php $__currentLoopData = $orderCity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($city->city); ?>"  <?php echo e(request('cityFilter') == $city->city ? "selected" : ""); ?>><?php echo e($city->city); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </li>
                                            <?php if(request('statusFilter') === 'Dispatched'): ?>
                                                <li>
                                                    <select name="dispatchBy" class="form-control order-filter">
                                                        <option value="" disabled selected>Dispatch By</option>
                                                        <option value="all"  <?php echo e(request('dispatchBy') == 'all' ? "selected" : ""); ?>>All</option>
                                                        <option value="Tcs" <?php echo e(request('dispatchBy')  == 'Tcs' ? 'selected' : ''); ?>>Tcs</option>
                                                        <option value="Stallion" <?php echo e(request('dispatchBy')  == 'Stallion' ? 'selected' : ''); ?>>Stallion</option>
                                                        <?php $__empty_1 = true; $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <option value="<?php echo e($rider->id); ?>" <?php echo e(request('dispatchBy')  == $rider->id ? 'selected' : ''); ?>><?php echo e($rider->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </li>
                                            <?php endif; ?>
                                            <li>
                                                <select name="statusFilter" class="form-control order-filter">
                                                    <option value="" disabled selected>Select The status</option>
                                                    <option value="Hold Order" <?php echo e(request('statusFilter')  == 'Hold Order' || request('status') == 'Hold Order' ? 'selected' : ''); ?>>On Hold</option>
                                                    <option value="Dispatched" <?php echo e(request('statusFilter')  == 'Dispatched' || request('status') == 'Dispatched' ? 'selected' : ''); ?>>Dispatch</option>
                                                    <option value="Latest" <?php echo e(request('statusFilter')  == 'Latest' || request('status') == 'Latest' ? 'selected' : ''); ?>>Latest</option>
                                                    <option value="Canceled" <?php echo e(request('statusFilter')  == 'Canceled' || request('status') == 'Canceled' ? 'selected' : ''); ?>>Canceled</option>
                                                    <option value="Proceeded" <?php echo e(request('statusFilter')  == 'Proceeded' || request('status') == 'Proceeded' ? 'selected' : ''); ?>>Proceeded</option>
                                                </select>
                                            </li>
                                            <li>
                                                <select name="dispatch_status" class="form-control" id="dispatchStatus">
                                                    <option value="" disabled selected>Select dispatch Status</option>
                                                    <option value="all"  <?php echo e(request('dispatch_status') == 'all' ? "selected" : ""); ?>>All</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $dispatchOrderStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <?php if($dos->dispatch_status !== null && $dos->dispatch_status !== ''): ?>
                                                            <option  value="<?php echo e($dos->dispatch_status); ?>" <?php echo e(request('dispatch_status')  == $dos->dispatch_status ? 'selected' : ''); ?>><?php echo e($dos->dispatch_status); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <?php endif; ?>
                                                </select>
                                            </li>
                                        </form>
                                        <li class="exportas">
                                            <div class="filter-export">
                                                <form action="<?php echo e(route('employee_sync_record')); ?>" method="get">
                                                    <button type="submit" class="btn btn-primary"><i class="fa fa-recycle mr-2"></i>Sync Record</button>
                                                </form>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive" >
                            <table class="table card-table table-vcenter text-nowrap" id="table_id">
                                <thead>
                                <tr>
                                    <th class="w-1">Order ID <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="id"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="id"></i></th>
                                    <?php if(request('statusFilter') === 'Dispatched'): ?>
                                        <th class="w-1">CN</th>
                                        <th class="w-1">Dispatch Status</th>
                                    <?php endif; ?>
                                    <th>Name <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="name"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="name"></i></th>
                                    <th>Product URL <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="product"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="product"></i></th>
                                    <th>Address <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="address"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="address"></i></th>
                                    <th>City <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="city"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="city"></i></th>
                                    <th>Cell Number</th>
                                    <th>QTY <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="quantity"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="quantity"></i></th>
                                    <th>Price <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="price"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="price"></i></th>
                                    <th>Status <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="status"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="status"></i></th>
                                    <th>Date <i class="ion-arrow-down-b sorting-orders" data-type="desc" data-column="created_at"></i><i class="ion-arrow-up-b sorting-orders" data-type="asc" data-column="created_at"></i></th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody id="mainTableBody">
                                <?php echo $__env->make('employee.order.order-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </tbody>
                            </table>

                            <?php echo e($orders->links()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('employee.order.status-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $(document).on('change','.order-filter',function (e) {
                $('#orderFilterForm').submit();
            });
            $(document).on('click','.isReturned',function (e) {
                if($(this).prop("checked") == false){
                    toastr.error('You are not allowed to change this', 'error!');
                    $(this).prop("checked", true);
                }else{
                    let order_id = $(this).attr('data-id');
                    let url = '<?php echo e(route('employee_received_parcel','id')); ?>';
                    url = url.replace('id',order_id);
                    let data ={
                        '_token' : '<?php echo e(csrf_token()); ?>'
                    };

                    swal.fire({
                        title: "Did you receive the parcel?",
                        text: "You will not be able to revert this action!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sure'
                    }).then((result) => {
                        if (result.value) {
                            $.post(url,data,function (response) {
                                if (response.status == 'success'){
                                    toastr.success('Parcel received successfully', 'success!');
                                }
                            });
                        } else {
                            swal.fire(  "Your data is safe!");
                            $(this).prop("checked", false);

                        }
                    });
                }
            });

            $(document).on('click','.changeStatus',function (e) {
                e.preventDefault();
                let id = $(this).data('id');
                let value = $(this).data('value');

                let url ='<?php echo e(route('employee_update_order_status','id')); ?>'
                url = url.replace('id',id);
                let data = {
                    '_token' : '<?php echo e(csrf_token()); ?>',
                    'status' : value
                }
                $.post(url,data,function (response) {
                    if(response.status == 'success'){
                        // $("#table_id").load(window.location + " #table_id");
                        setTimeout(function(){// wait for 5 secs(2)
                            location.reload(); // then reload the page.(3)
                        }, 1000);
                        toastr.success('Status Updated Successfully', 'Success!')

                    }else{
                        toastr.error('Something went wrong', 'error!')
                    }
                });

            });
            $(document).on('change','.orderDateFilter',function (e) {
                e.preventDefault();
                let fromDate = $('input[name="fromDate"]').val();
                let toDate = $('input[name="toDate"]').val();
                let url = '<?php echo e(route('employee_filter_order')); ?>';
                let data = {
                    "fromDate" : fromDate,
                    "toDate" : toDate,
                };
                if(fromDate && toDate){
                    $('#orderFilterForm').submit();
                };
            });

            $("#search").bind('blur keyup', function(e) {
                if (e.type === 'blur' || e.keyCode === 13) {
                    e.preventDefault();
                    $('#orderFilterForm').submit();

                    
                    
                    
                    
                    
                    
                    
                }
            });

            $(document).on('change',"select[name='dispatch_status']",function (e) {
                e.preventDefault();
                let dispatch_status = $(this).val();
                if(dispatch_status !== ''){
                    $('#orderFilterForm').submit();
                };
            });

            $("select[name='bulk-action']" ).on('change',function (e) {
                e.preventDefault();
                let type = $( "#deleteAll option:selected" ).data('type');
                let value = $( "#deleteAll option:selected" ).val();
                let orders =[];
                $("input:checkbox[name=orderCheck]:checked").each(function(){
                    orders.push($(this).data('id'));
                });

                if (orders.length == 0 ){
                    toastr.error('Please Select at least one order ', 'error!')
                }else{
                    let data = { "orders": orders,"_token": "<?php echo e(csrf_token()); ?>","_method" : "DELETE","action" : type,"statusType" : value};
                    let url = "<?php echo e(route('employee_delete_multiple_order')); ?>";

                    swal.fire({
                        title: "Are you sure?",
                        text: "You will not be able to revert this action!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sure'
                    }).then((result) => {
                        if (result.value) {
                            $.post(url,data,function (response) {
                                if(response.status == 'success'){

                                    $('#mainTableBody').empty().append(response.view);

                                    if(response.action == 'delete'){
                                        toastr.success('Orders Deleted Successfully', 'Success!')
                                    }else{
                                        toastr.success('Status Updated Successfully', 'Success!')
                                    }

                                    setTimeout(function(){// wait for 5 secs(2)
                                        location.reload(); // then reload the page.(3)
                                    }, 10);
                                    $('.checkboxes').prop("checked",false);
                                    $(".checkboxes").attr("autocomplete", "off");
                                    $('#totalSelected').empty();
                                }else{
                                    toastr.error('Something went wrong', 'error!')
                                }
                            });
                        } else {
                            swal.fire(  "Your data is safe!");
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/employee/order/all-order.blade.php ENDPATH**/ ?>