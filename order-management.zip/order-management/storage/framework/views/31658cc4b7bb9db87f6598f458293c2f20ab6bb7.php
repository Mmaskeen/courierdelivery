<tr>
    <td>Order-ID</td>
    <td>CN</td>
    <td>Dispatch Status</td>
    <td>Name</td>
    <td>Address</td>
    <td>Product url</td>
    <td>Quantity</td>
    <td>Mobile Number</td>
    <td>Price</td>
    <td>Email</td>
    <td>Status</td>
    <td>City</td>
    <th>Remarks</th>
    <th>Created_at</th>
    <th>Deleted_at</th>
</tr>
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($order->order_id); ?></td>
        <td><?php echo e($order->cn); ?></td>
        <td><?php echo e($order->dispatch_status); ?></td>
        <td><?php echo e($order->name); ?></td>
        <td><?php echo e($order->address); ?></td>
        <td><?php echo e($order->product); ?></td>
        <td><?php echo e($order->quantity); ?></td>
        <td>
            <?php $__currentLoopData = $order->orderNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($num->mobile); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td><?php echo e($order->price); ?></td>
        <td><?php echo e($order->email); ?></td>
        <td><?php echo e($order->status); ?></td>
        <td><?php echo e($order->city); ?></td>
        <td>
            <?php $__currentLoopData = $order->remarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($remark->remark); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td><?php echo e($order->created_at); ?></td>
        <td><?php echo e($order->deleted_at); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/order-management/resources/views/admin/export/export-selected-order.blade.php ENDPATH**/ ?>