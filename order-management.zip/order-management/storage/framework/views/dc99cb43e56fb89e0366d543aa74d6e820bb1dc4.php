<?php $__env->startSection('page-title'); ?>
    <title>Admin | New Order</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container-fluid">
            <div class="page-header">
                <h4 class="page-title">Order Detail </h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);">New Order</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Order Detail</li>
                </ol>
            </div>
            <div class="row row-cards">
                <div class="col-md-12 wrapper wrapper-content animated fadeInRight">
                    <div class="ibox card">
                        <div class="card-header">
                            <h5 class="card-title">Order Detail</h5>
                        </div>
                        <div class="card-body">
                            <div class="ibox-content">
                                <div class="row">

                                    <div class="col-md-12 col-lg-12">
                                        <div class="card-body p-5">
                                            <h3>
                                                <a href="javascript:void(0);" class="text-navy">
                                                    <?php echo e($order->name); ?>

                                                </a>
                                            </h3>
                                            <div class="mb-3">
                                                <span class="font-weight-bold h1 text-danger"><?php echo e($order->price); ?></span>
                                            </div>
                                            <p class="small">
                                                <?php echo e($order->address); ?>

                                            </p>
                                            <h4 class="mt-4 mb-4 font-weight-semibold">Order Details</h4>
                                            <table class="table table-striped table-bordered m-top20">
                                                <tbody>
                                                <tr>
                                                    <th scope="row">Product:</th>
                                                    <td><?php echo e($order->name); ?> <?php echo e($order->product); ?></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">Quantity:</th>
                                                    <td><?php echo e($order->quantity); ?></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">Model</th>
                                                    <td><?php echo e($order->model); ?></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">Email</th>
                                                    <td><?php echo e($order->email); ?></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">Size</th>
                                                    <td><?php echo e($order->size); ?></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">Mobile</th>
                                                    <td>
                                                        <?php $__empty_1 = true; $__currentLoopData = $order->orderNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <?php echo e($num->mobile); ?> ,
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            N/A
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">CMO Number</th>
                                                    <td><?php echo e($order->cmo); ?></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">City</th>
                                                    <td><?php echo e($order->city); ?></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">Remarks</th>
                                                    <td>
                                                        <?php $__empty_1 = true; $__currentLoopData = $order->remarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <?php echo e($remark->remark); ?> <br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            N/A
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>

                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/admin/order/new-order.blade.php ENDPATH**/ ?>