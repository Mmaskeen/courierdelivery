<?php $__env->startSection('page-title'); ?>
    <title>Employee | Add New Order</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container-fluid">
            <div class="page-header">
                <h4 class="page-title">Orders</h4>
            </div>
            <div class="row">
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 card-title">Add New Order</h3>
                        </div>
                        <form method="post" action="<?php echo e(route('employee_store_order')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Shop Name</label>
                                            <input type="text" class="form-control" value="<?php echo e(old('shop_name')); ?>" name="shop_name" placeholder="Shop Name">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Enter Name</label>
                                            <input type="text" class="form-control" value="<?php echo e(old('customer_name')); ?>" name="customer_name" placeholder="Name">
                                            <?php if ($errors->has('customer_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_name'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Product</label>
                                            <input type="text" class="form-control" value="<?php echo e(old('product_url')); ?>" name="product_url" placeholder="Product">
                                            <?php if ($errors->has('product_url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_url'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Email</label>
                                            <input type="text" class="form-control" value="<?php echo e(old('customer_email')); ?>" name="customer_email" placeholder="Email..">
                                            <?php if ($errors->has('customer_email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_email'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group m-0" id="mobileDiv">
                                            <label class="form-label">Mobile</label>
                                            <input type="text"  class="form-control mobile" value="" name="mobile[]" placeholder="Mobile Number" required>
                                            <button class="at-plusicon" id="addNumber"><i class="fa fa-plus" aria-hidden="true"></i></button>
                                            <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">City</label>
                                            <select class="form-control cities" name="city" data-placeholder="Choose City">
                                                <option value="" disabled selected>Select The City</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($city->name); ?>"  <?php echo e(old('city') == $city->name ? "selected" : ""); ?>><?php echo e($city->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        
                                        
                                        
                                        
                                    </div>
                                    <div class="col-md-6">
                                        
                                        
                                        
                                        

                                        
                                        <div class="form-group">
                                            <label class="form-label">Address</label>
                                            <input type="text" class="form-control" value="<?php echo e(old('customer_address')); ?>" name="customer_address" placeholder="Address">
                                            <?php if ($errors->has('customer_address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_address'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group m-0">
                                            <label class="form-label">Quantity</label>
                                            <input type="number" class="form-control" value="<?php echo e(old('product_quantity')); ?>" name="product_quantity" placeholder="Quantity">
                                            <?php if ($errors->has('product_quantity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_quantity'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Price</label>
                                            <input type="number" class="form-control" value="<?php echo e(old('price')); ?>" name="price" placeholder="Price">
                                            <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Currency</label>
                                            <input type="text" class="form-control" value="Pkr" name="currency" placeholder="Currency">
                                            <?php if ($errors->has('currency')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currency'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Remarks</label>
                                            <input type="text" class="form-control" name="remarks" value="<?php echo e(old('remarks')); ?>" placeholder="Remarks">
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="card-footer text-right">
                                <button type="submit" class="btn btn-primary">Add Order</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('.mobile').mask('0000-000000000000000000000000000000');
            $(document).on('click','#addNumber',function (e) {
                e.preventDefault();
                let input = '<input type="text"  class="form-control mobile " value="" name="mobile[]" placeholder="Mobile Number 2">';
                $('#mobileDiv').append(input);
                $('.mobile').mask('0000-000000000000000000000000000000');
                $(this).hide();
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/employee/order/create-order.blade.php ENDPATH**/ ?>