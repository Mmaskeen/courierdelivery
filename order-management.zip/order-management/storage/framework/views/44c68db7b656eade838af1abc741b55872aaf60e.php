<?php $__env->startSection('page-title'); ?>
    <title>Admin | Add New Rider</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="content-area">
        <div class="container-fluid">
            <div class="page-header">
                <h4 class="page-title">Riders</h4>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 card-title">Add New Rider</h3>
                        </div>
                        <form method="post" action="<?php echo e(route('admin_store_rider')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Enter Name</label>
                                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>"  placeholder="Name" required>
                                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label">Email</label>
                                            <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>"  placeholder="Email.." required>
                                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label">Phone</label>
                                            <input type="number" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>"  placeholder="Phone">
                                            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> <div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Notes</label>
                                                <textarea rows="5" class="form-control" name="bio"   placeholder="Enter About your description"><?php echo e(old('bio')); ?></textarea>
                                            </div>
                                            <div class="form-group m-0">
                                                <label class="form-label">Profile Picture</label>
                                                <input type="file" class="form-control" accept="image/*" name="file">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer text-right">
                                    <button type="submit" class="btn btn-primary">Add Rider</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/order-management/resources/views/admin/rider/create-rider.blade.php ENDPATH**/ ?>