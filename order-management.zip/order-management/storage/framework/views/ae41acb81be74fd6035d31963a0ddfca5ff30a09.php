<!--footer-->
<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 mt-3 mt-lg-0 text-center">
                Copyright © 2020 - 2020 <a href="www.renesistech.com">Renesis Tech Pvt Ltd</a>. Designed by <a href="www.renesistech.com">Renesis Tech</a> All rights reserved.
            </div>
        </div>
    </div>
</footer>
<!-- End Footer-->
</div>
</div>
</div>
<!-- Back to top -->
<a href="index.php#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>
<?php /**PATH /var/www/order-management/resources/views/layouts/footer.blade.php ENDPATH**/ ?>