<?php

namespace App\Console\Commands;

use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;

class CheckOrderStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'order:status';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check tcs order status';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $a = "DELIVERED";
        $b = "Returned to TCS origin";

        $or = Order::where('dispatch_by','Tcs')->where('cn','!=',null)->where(function ($q) use($a,$b){
            $q->where('dispatch_status',null)->orWhereNotIn('dispatch_status',[$a,$b]);
        });

        $orders = $or->get();
        foreach ($orders as $order){
            if ($order->cn !== null){
                $response = Curl::to('https://apis.tcscourier.com/production/track/v1/shipments/detail')
                    ->withHeaders( array( 'accept: application/json', 'X-IBM-Client-Id: 51a21837-3d33-4760-b172-2e036a509cbf' ,
                    ) )
                    ->withData( array("consignmentNo" => $order->cn) )
                    ->asJson()
                    ->get();

                if ($response->returnStatus->status == "SUCCESS"){
                    if ($response->TrackDetailReply) {
                        if (isset($response->TrackDetailReply->DeliveryInfo)) {
                            $order->update([
                                'dispatch_status' => $response->TrackDetailReply->DeliveryInfo[0]->status,
                            ]);
                        } elseif(isset($response->TrackDetailReply->Checkpoints)) {
                            $order->update([
                                'dispatch_status' => $response->TrackDetailReply->Checkpoints[0]->status,
                            ]);
                        }
                    }
                }elseif ($response->returnStatus->status == "FAIL"){
                    $order->update([
                        'dispatch_status' => $response->returnStatus->message,
                    ]);
                }
            }
        }
    }
}
